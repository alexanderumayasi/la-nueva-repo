// index.js

// Función para manejar la redirección de búsqueda
function handleSearchRedirection() {
    const searchBar = document.querySelector('.search input[type="search"]');
    const searchButton = document.querySelector('.search button');

    // Manejar el evento de la tecla Enter en la barra de búsqueda
    searchBar.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            e.preventDefault(); // Evita el envío del formulario
            redirectToCatalog();
        }
    });

    // Manejar el clic en el botón de búsqueda
    searchButton.addEventListener('click', (e) => {
        e.preventDefault(); // Evita el envío del formulario
        redirectToCatalog();
    });

    function redirectToCatalog() {
        const searchData = searchBar.value.toLowerCase();
        localStorage.setItem('searchTerm', searchData);
        window.location.href = 'all_products.html';
    }
}

// Inicializar la redirección de búsqueda
handleSearchRedirection();
